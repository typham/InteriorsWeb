﻿using Interiors.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Interiors.Controllers
{
    public class HomeController : Controller
    {
        InteriorsEntities db = new InteriorsEntities();
        public ActionResult Index()
        {
            var slideHome = db.Configurations.Where(i => i.ConfigCode == "SlideHome");
            return View(slideHome);
        }

        public ActionResult Header()
        {
            var Menu = db.Configurations.Where(i => i.ConfigCode == "menu");
            return PartialView("_Header",Menu);
        }
    }
}