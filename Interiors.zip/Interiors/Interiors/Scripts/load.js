var ua = navigator.userAgent;
var androidversion = parseFloat(ua.slice(ua.indexOf("Android")+8)); 
var isTouchDevice =  "ontouchstart" in window || window.DocumentTouch && document instanceof DocumentTouch;
var isTouch = "ontouchstart" in window || window.navigator.msMaxTouchPoints;
var isDesktop = $(window).width() != 0 && !isTouchDevice ? true : false;
var isTouchIE =  navigator.userAgent.toLowerCase().indexOf('msie') != -1 && navigator.msMaxTouchPoints > 0;
var isIE11 = !!window.MSStream;
var isiPad = navigator.userAgent.indexOf('iPad') != -1;
var isiPhone = navigator.userAgent.indexOf('iPhone') != -1;
var isiPod = navigator.userAgent.indexOf('iPod') != -1;
var isAndroid = navigator.userAgent.indexOf('Android') != -1; 
var isIE = navigator.userAgent.toLowerCase().indexOf('msie') != -1 && $(window).width() != 0; 
var isChrome = navigator.userAgent.toLowerCase().indexOf('chrome') > -1;
var isFirefox = navigator.userAgent.toLowerCase().indexOf('firefox') > -1;
var isSafari = navigator.userAgent.toLowerCase().indexOf('safari') > -1;
var IEMobile = "-ms-user-select" in document.documentElement.style && navigator.userAgent.match(/IEMobile\/10\.0/);
var match = navigator.userAgent.match('MSIE (.)');
//var version = match && match.length > 1 ? match[1] : 'unknown';
// Check Safari version 
var userAgent = navigator.userAgent.toLowerCase(),
version  = 0;
userAgent = userAgent.substring(userAgent.indexOf('safari/') + 7);	
userAgent = userAgent.substring(0,userAgent.indexOf('.'));
version = userAgent;	

var Loadx = 0;

function changeUrl(url, title, description, keyword, dataName, titleog, descriptionog) {
    if (window.history.pushState !== undefined) {
        var c_href = document.URL;
        if (c_href != url && url!='')
            window.history.pushState({path: url, dataName: dataName, title: title, keyword: keyword, description: description, titleog: titleog, descriptionog: descriptionog}, "", url);
    }
    if (title != '') {
        $('#hdtitle').html(title);
        $('meta[property="og:description"]').remove();
        $('#hdtitle').after('<meta property="og:description" content="' + descriptionog + '">');
        $('meta[property="og:title"]').remove();
        $('#hdtitle').after('<meta property="og:title" content="' + titleog + '">');
        $('meta[property="og:url"]').remove();
        $('#hdtitle').after('<meta property="og:url" content="' + url + '">');
        $('meta[name=keywords]').remove();
        $('#hdtitle').after('<meta name="keywords" content="' + keyword + '">');
        $('meta[name=description]').remove();
        $('#hdtitle').after('<meta name="description" content="' + description + '">');
    }
    $('#changlanguage_redirect').val(url);
}

function hiddenZoom(){
	var activePicLarge = $('.slide-item.select').find('.slide-product .pro-full img').attr("data-zoom");

	 if(activePicLarge==''){
		 if ($(window).width() > 1100) {
			$('.close').css('margin','0 100px');
		 }else{
			 $('.close').css('margin','0 20px');
		 }
		 $('.zoom-full').css('display','none');
	 }else{
		 if ($(window).width() > 1100) {
			$('.close').css('margin','0 100px');
		 }else{
			 $('.close').css('margin','0 20px');
		 }
		 $('.zoom-full').css('display','inline-block');
	 }
}

function ResizeWindows() {
var Portrait = $(window).height() > $(window).width();
var Landscape = $(window).height() <= $(window).width();
var img = $('.bg-home img');
var Xwidth = $(window).width();
var Yheight = $(window).height();
var RatioScreeen = Yheight / Xwidth;
var RatioIMG = 747 / 1440;
var RatioBanner = 450 / 1440;
var newXwidth;
var newYheight;
if(RatioScreeen > RatioIMG){
	  newYheight = Yheight;
	  newXwidth	= Yheight / RatioIMG;
 }else{
	  newYheight = Xwidth * RatioIMG;
	  newXwidth	= Xwidth;
	  
}

if( $('.box-size').text().length>0){
	$('.box-size').css({'display':'inline-block'});
}else{
	$('.box-size').css({'display':'none'});
}
$('html, body').css({'width':Xwidth});
$('.container').css({'min-height':Yheight});
$('.news-load, .wrap-content, .load-product').css({'min-height':Yheight/2});

$('.page-overflow, .colum-box').css({'width':Xwidth});
var allItem = $('.colum-box').length;
var widthItem = $('.colum-box').width(); 
$('.box-content').width(allItem * widthItem);  
					 
			
				 if(Xwidth <= 1100){
					
					$('.nav-click').css({'display':'block', 'opacity':1});
					$('.scroll-down').css({'top':Yheight-70});
					
					if(Xwidth <= 420){
					   $(img).css({'width': Xwidth+400, 'height': (Xwidth+400)* RatioIMG, 'left':-200, 'top':0, 'bottom':'auto'});
					   $('.bg-home').css({'width': Xwidth, 'height':(Xwidth+400) * RatioIMG});
					    $('.slide-bg, .slider-home').css({'width': '100%', 'height':(Xwidth+400) * RatioIMG});
					
					    if(isTouchIE || isIE11 || IEMobile || isIE){
	                    $('.content-text').css({'column-count':1, 'column-gap':0});
                      }
					}else if(Xwidth > 420 && Xwidth <= 620){
					   $(img).css({'width': Xwidth+300, 'height': (Xwidth+300)* RatioIMG, 'left':-150, 'top':0, 'bottom':'auto'});
					   $('.bg-home').css({'width': Xwidth, 'height':(Xwidth+300) * RatioIMG});
					     $('.slide-bg, .slider-home').css({'width': '100%', 'height':(Xwidth+300) * RatioIMG});
					
					   if(isTouchIE || isIE11 || IEMobile || isIE){
	                    $('.content-text').css({'column-count':1, 'column-gap':0});
                      }
					}else{
					   $(img).css({'width': Xwidth, 'height': Xwidth * RatioIMG, 'left':0,'top':0, 'bottom':'auto'});
					   $('.bg-home').css({'width': Xwidth, 'height':Xwidth * RatioIMG});
					    $('.slide-bg, .slider-home').css({'width': '100%', 'height':Xwidth * RatioIMG});
					  
					   if(isTouchIE || isIE11 || IEMobile || isIE){
	                    $('.content-text').css({'column-count':2, 'column-gap':40});
                      }
					}
					
					 if(Xwidth <= 520){
						  $('.close-box').css({'display':'block'});
					  }
					
					if(Portrait){
						$('.banner, .bg-cover').css({'height':(Xwidth+400) * RatioBanner});
					}else{
						$('.banner, .bg-cover').css({'height':(Xwidth+200) * RatioBanner});
					}
					
					
					   $('.banner img').each(function(index, element) {
							$(this).css({'margin-left': Xwidth/2 - $(this).width()/2});
				    	});
					 
					 $('.navigation,.nav, .sub-nav').css({'width':260});
					 
					 $('.box-video .pic img').css({'height':'auto', 'margin-top':0, 'width':'100%'});
				
					 $('.right-pro').css({'width':'90%','margin':'0 5%'});
					
					 var totalWidth = 0;
					 $('.tab-menu li').each(function(index, element) {
                       var widthThumb = $(this).outerWidth()+40;
					    totalWidth += parseInt(widthThumb);
                        $('.tab-menu ul').width(totalWidth);
				 	 });
					 
					 
					 if ($('#gallery-page').length) {
						 $('.pic-content').each(function(index1, element1) {
						 $(element1).find(".slide-pagination .slide-page").each(function(index, element) {
							   if(index>4){
								   $(element).css('display','none');
							   }
						   });
						 });
						   
					 }
					
					 
				 }else if( Xwidth > 1100){
					
					 $('.nav-click').css({'display':'none','opacity':0});
					 $('.scroll-down, .go-top').css({'display':'none', 'opacity':0});
					 $('.show-box, .close-box').css({'display':'none'});
					 $('.left-content').addClass('move').removeClass('view-box').removeClass('hide-box');
					
					 $(img).css({'width': newXwidth,'height': newYheight,'left':(Xwidth - newXwidth) / 2,'top':'auto', 'bottom':0});
                     $('.bg-home').css({'width':Xwidth, 'height':Yheight});
					 $('.slide-bg, .slider-home').css({'width':'100%', 'height':Yheight});
					 $('.banner, .bg-cover').css({'height':Xwidth * RatioBanner});
					 if(isTouchIE || isIE11 || IEMobile || isIE){
	                    $('.content-text').css({'column-count':2, 'column-gap':50});
                      }
					  
                      $('.navigation, .sub-nav').css({'width':Xwidth-452});
					  $('.nav').css({'width':Xwidth-503});
					  $('.overlay-menu').css({'height':0});
  
	                //  $('.box-video .pic img').each(function(index, element) {
						   $('.box-video .pic img').load(function(){
							 var RatioPic =  $(this).width() / $(this).height();
						  if(RatioPic < 1 ){
							  $(this).css({'height':'100%', 'margin-top':0, 'width':'auto'});
						  }else{
							  $(this).css({'height':'auto' ,'margin-top':80 - $(this).height()/2, 'width':'100%'});
						  }
						  });
				    	//});
					 
					   $('.banner img').css({'margin-left': 0});
	                   $('.next-prev').css({'top':Yheight/2-35});
					   $('.scroll-down-desktop').css({'top':Yheight-60});
					   
					   if($('.left-pro').children().length){
						   $('.right-pro').css({'width':'65%','margin':'0 -2px'});
					   }else{
						   $('.right-pro').css({'width':'90%','margin':'0 5%'});
					   }
				         
						$('.tab-menu ul').css({'width':'100%'});
						
						
						if ($('#gallery-page').length) {
						 
						 $('.pic-content').each(function(index1, element1) {
						 $(element1).find(".slide-pagination .slide-page").each(function(index, element) {
							   //if(index>5){
								   $(element).css('display','inline-block');
							   //}
						   });
						 });
						   
					 }
						
		       }
			   
   
		     $('.box-content').css({'height':$('.box-content .colum-box.active').innerHeight()});  
			   
			   			/*******/
						//$('.slide-next, .slide-prev, .slide-page').click(function() {
							// hiddenZoom();
					 	//})
						/*******/
						
			         if ($('#download-page').length) {
						      var Item =	 $('.slide-pictures.two').find('.slide-item');
							   if(Item>2){
								    $('.slide-pictures.two .slide-item').css({'display':'block', 'float':'left'});
							   }else{
								    $('.slide-pictures.two .slide-item').css({'display':'inline-block', 'float':'none'});
									$('.slide-pictures.two  .slide-wrapper').css({'width':'auto'});
							   }
					  }		
						
						  if ($('.info-award').text()>0) {
							  $('.info-award').css({'display':'block'});
						  }else{
							  $('.info-award').css({'display':'none'});
						  }
					 	
						 $('.no-height').css({'height': $('.all-colum .colum:nth-child(3)').innerHeight()-54});
						 $('.listpro ul').css({'height': $('.all-colum .colum:nth-child(3)').innerHeight()-54});
						
  
}








function Done() {
	 ResizeWindows();
	$('.loadicon').fadeOut(500, function () {  
	   $('html, body').scrollTop(0);
	    ContentLoad();
	   $('.container').css({'opacity':1});
	   $('.loadicon').remove();
	});
}





(function($) {
	
    if (!Array.prototype.indexOf)
	   {
	   Array.prototype.indexOf = function(elt /*, from*/)
             {
             var len  = this.length >>> 0;
             var from = Number(arguments[1]) || 0;
                 from = (from < 0)
                      ? Math.ceil(from)
                      : Math.floor(from);
             if (from < 0)
                 from += len;
 
                 for (; from < len; from++)
                     {
                     if (from in this &&
                     this[from] === elt)
                     return from;
                     }
             return -1;
             };
       }

    var Yheight = $(window).height();
    var Xwidth = $(window).width();	
    var qLimages = new Array;
    var qLdone = 0;
    var qLdestroyed = false;
    var qLimageContainer = "";
    var qLoverlay = "";
    var qLbar = "";
    var qLpercentage = "";
    var qLimageCounter = 0;
    var qLstart = 0;

    var qLoptions = {
        onComplete: function () {
			      $('#qLoverlay').remove();
			      $('body .item-load').remove();
			   },
        backgroundColor: "#fff",
        barColor: "#fff",
        barHeight: 1,
        percentage: true,
        deepSearch: true,
        completeAnimation: "fade",
        minimumTime: 500,
        onLoadComplete: function () {
            if (qLoptions.completeAnimation == "grow") {
                var animationTime = 100;
                var currentTime = new Date();
                if ((currentTime.getTime() - qLstart) < qLoptions.minimumTime) {
                    animationTime = (qLoptions.minimumTime - (currentTime.getTime() - qLstart));
                }

                 $('#qLbar').stop().animate({"width": "100%"}, animationTime, function () {
					    
						  $('#qLoverlay').fadeOut(200, function () {      
						         qLoptions.onComplete();
								  if( Loadx == 0){
									  Loadx = 1;
                                      Done();
                                   }
								 ResizeWindows();
								
                          });
                });
			}
		}
            
    };
	
	      
    var afterEach = function () {
        //start timer
        var currentTime = new Date();
        qLstart = currentTime.getTime();

        createPreloadContainer();
        createOverlayLoader();
    };

    var createPreloadContainer = function() {
         qLimageContainer = $('<div class="item-load"></div>').appendTo("body").css({
            display: "none",
            width: 0,
            height: 0,
            overflow: "hidden"
        });
        for (var i = 0; qLimages.length > i; i++) {
            $.ajax({
                url: qLimages[i],
                type: 'HEAD',
                success: function(data) {
                    if(!qLdestroyed){
                        qLimageCounter++;
                        addImageForPreload(this['url']);
                    }
                }
            });
        }
    };

    var addImageForPreload = function(url) {
        var image = $("<img />").attr("src", url).bind("load", function () {
            completeImageLoading();
        }).appendTo(qLimageContainer);
    };

    var completeImageLoading = function () {
        qLdone++;

        var percentage = (qLdone / qLimageCounter) * 100;
        $(qLbar).stop().animate({
            width: percentage + "%",
            minWidth: percentage + "%"
        }, 200);

        if (qLoptions.percentage == true) {
            $(qLpercentage).text(Math.ceil(percentage) + "%");
        }

        if (qLdone == qLimageCounter) {
            destroyQueryLoader();
        }
    };

    var destroyQueryLoader = function () {
        $(qLimageContainer).remove();
        qLoptions.onLoadComplete();
        qLdestroyed = true;
    };

    var createOverlayLoader = function () {
            qLoverlay = $('<div id="qLoverlay"></div>').css({
            width: "100%",
            height: "10px",
            position: "absolute",
            zIndex:1000,
            top: 0,
            left: 0,
        }).appendTo("body");
        qLbar = $('<div id="qLbar"></div>').css({
            height: qLoptions.barHeight + "px",
            backgroundColor: qLoptions.barColor,
            width: "0%",
            position: "absolute",
            top: "0px"
        }).appendTo(qLoverlay);
        if (qLoptions.percentage == true) {
            qLpercentage = $('<div id="qLpercentage"></div>').text("0%").css({
               height: "120px",
			   width: "120px",
			   position: "absolute",
			   fontSize: "0px",
			   top: "50%",
			   left: "50%",
			   marginTop: "60px" ,
			   textAlign: "center",
			   marginLeft: "-60px",
			   color: "#fff"
            }).appendTo(qLoverlay);
        }
    };

    var findImageInElement = function (element) {
        var url = "";

        if ($(element).css("background-image") != "none") {
            var url = $(element).css("background-image");
        } else if (typeof($(element).attr("src")) != "undefined" && element.nodeName.toLowerCase() == "img") {
            var url = $(element).attr("src");
        }

        if (url.indexOf("gradient") == -1) {
            url = url.replace(/url\(\"/g, "");
            url = url.replace(/url\(/g, "");
            url = url.replace(/\"\)/g, "");
            url = url.replace(/\)/g, "");

            var urls = url.split(", ");

            for (var i = 0; i < urls.length; i++) {
                if (urls[i].length > 0 && qLimages.indexOf(urls[i]) == -1) {
                    var extra = "";
                    qLimages.push(urls[i] + extra);
                }
            }
        }
    }

    $.fn.queryLoader = function(options) {
        if(options) {
            $.extend(qLoptions, options );
        }

        this.each(function() {
            findImageInElement(this);
            if (qLoptions.deepSearch == true) {
                $(this).find("*:not(script)").each(function() {
                    findImageInElement(this);
                });
            }
        });

        afterEach();

        return this;
    };

})(jQuery);



$(document).ready(function () {
$('html, body').scrollTop(0);
$('body').append('<div class="loadicon" style="display:block"><span class="circle"></span></div>');	
$('body').queryLoader({ barColor: "#fff", percentage: true, barHeight:1, completeAnimation: "grow",  minimumTime:100});	
ResizeWindows();
setTimeout(function(){if( Loadx == 0){ Loadx = 1;  Done();}}, 5000);
});

