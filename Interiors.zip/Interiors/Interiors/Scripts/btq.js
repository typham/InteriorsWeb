(function($) {
    var methods = {on: $.fn.on, bind: $.fn.bind};
    $.each(methods, function(k) {
        $.fn[k] = function() {
            var args = [].slice.call(arguments),
                    delay = args.pop(),
                    fn = args.pop(),
                    timer;
            args.push(function() {
                var self = this,
                        arg = arguments;
                clearTimeout(timer);
                timer = setTimeout(function() {
                    fn.apply(self, [].slice.call(arg));
                }, delay);
            });
            return methods[k].apply(this, isNaN(delay) ? arguments : args);
        };
    });
}(jQuery));


var timex;
var Click;
var News;
var shownews;
var show;
var Scroll = 0;
var Menu = 0;
var SubMenu = 0;
var Details = 0;
var doWheel = true;
var doTouch = true;
var Arrhash;
function execSearch() {
    var qsearch = $('#qsearch').val();
    var href_search = $('#href_search').val();
    var defaultvalue = $('#defaultvalue').val();

    if (qsearch == defaultvalue)
        return false;
    if (qsearch != '') {
        var url = href_search + '?qsearch=' + encodeURIComponent(qsearch)

        window.location = url;
        return false;
    }
}


function Search() {
    $('a.search').bind('click', function() {
		if($(window).width() > 1100){
			if (show == 1) {
				$('.form-row-search').css({'width': 0});
				$('.search-form').css({'width': 0, 'opacity':0});
				$('a.search').removeClass('active');
				show = 0;
				execSearch();
			} else {
				$('.form-row-search').css({'width': '100%'});
				$('.search-form').css({'width': 300, 'opacity':1});
				$('a.search').addClass('active');
				document.getElementById("search").reset();
				show = 1;
			 }
		}else{
			$('.form-row-search').css({'width': '100%'});	
			$('.search-form').css({'width': '80%', 'opacity':1});
			  if (show == 1) {
			  $('a.search').removeClass('active');
			  show = 0;
			  execSearch();
			 }else{
			  $('a.search').addClass('active');
			  document.getElementById("search").reset();
			  show = 1;
			 }
		}
    });
	
	
	$('#qsearch').keydown(function(e) {
        if (e.keyCode == 13) {
            execSearch();
        }
     });
	 
	 

}

function toggleVideo(tagiframe, state) {
    // if state == 'hide', hide. Else: show video
    var iframe = tagiframe[0].contentWindow;
    func = state == 'hide' ? 'pauseVideo' : 'playVideo';
    iframe.postMessage('{"event":"command","func":"' + func + '","args":""}', '*');
}



function NavClick() {
    $('.nav-click').bind('click', function() {
		if($(window).width() <= 1100){
        if ($(this).hasClass('active')) {
			 Scroll = 0;
			$('.container').removeClass('wrap');
            $('.nav-click').removeClass('active');
            $('.overlay-menu, .top, .header, .logo').removeClass('show');  
			$('html, body, .container').removeClass('no-scroll-nav');
        } else {
			Scroll = 1;
			$('html, body, .container').addClass('no-scroll-nav');
			$('.go-top').css({'display':'none', 'opacity':0});
			$('.container').addClass('wrap');
            $('.nav-click').addClass('active');
			if($(window).width()<=520){
				 $('.logo').addClass('show');
			}
			
            $('.overlay-menu, .top, .header').addClass('show');
			
          }
	   }
        return false;
		
    });

}

function SubClick() {
	
		  $('.nav li .has-sub').bind('click mouseenter',function(e){
		  e.preventDefault();
		  if($(window).width() > 1100){
			  if(!$(this).parent().hasClass('active')){
				$('.overlay-menu, .header').addClass('show'); 
				$('.title-name li').removeClass('show');
				$('.nav li').removeClass('active');
				$('.sub-menu').css({'height':0});
				var OpenPage = $(this).attr('data-sub');
				var Hx1 = $('.sub-menu[data-show= "' + OpenPage + '"] .all-sub:nth-child(1)').innerHeight();
				var Hx2 = $('.sub-menu[data-show= "' + OpenPage + '"] .all-sub:nth-child(2)').innerHeight();
				var Hx3 = $('.sub-menu[data-show= "' + OpenPage + '"] .all-sub:nth-child(3)').innerHeight();
				var Hx = 0;
				
				if(Hx1>Hx2){
					Hx = Hx1;
					if(Hx1>Hx3){
						Hx = Hx1;
					}else{
						Hx = Hx3;
					}
				}else{
					Hx=Hx2;
					if(Hx2>Hx3){
						Hx = Hx2;
					}else{
						Hx = Hx3;
					}
				}
				
				$('.sub-menu[data-show= "' + OpenPage + '"]').css({'height':Hx});
				
				$('.title-name li[data-name= "' + OpenPage + '"]').addClass('show');
				$(this).parent().addClass('active');
		   }else {
				$('.nav li').removeClass('active');
				$('.sub-menu').css({'height':0});
				$('.item-sub').removeClass('active');
	            $('.second-sub-menu').css({'height':0});
				$('.title-name li').removeClass('show');
			}
		  
		  }
		   return false;
         });
		 
		 $('.nav li .no-sub, .nav li .blank-sub').mouseenter(function(e){
		  e.preventDefault();
		  if($(window).width() > 1100){
			    $('.overlay-menu, .header').addClass('show'); 
				$('.title-name li').removeClass('show');
				$('.nav li').removeClass('active');
				$('.sub-menu').css({'height':0});
				var OpenPage = $(this).attr('data-sub');
				$('.title-name li[data-name= "' + OpenPage + '"]').addClass('show');
		    }
		   return false;
         });
		 
	   
	   
	    $('.item-sub.second').bind('click mouseenter',function(e){  
		  e.preventDefault();
		  if(!isTouchDevice && $(window).width() > 1100){
		   var Hx = $(this).parent().parent().find('.all-sub').innerHeight(); 
		  if(!$(this).hasClass('active')){
		   $('.item-sub.second').removeClass('active');
		   $('.second-sub-menu').css({'height':0});
		   var OpenPage = $(this).find('a').attr('data-sub');
		   var Hy = $('.second-sub-menu[data-show= "' + OpenPage + '"] .second-all-sub').innerHeight();
		   $('.second-sub-menu[data-show= "' + OpenPage + '"]').css({'height':Hy});
		    $(this).addClass('active');
			$(this).parent().parent().css({'height':Hx + Hy});
		  }else {
			  $('.item-sub.second').removeClass('active');;
			  $('.second-sub-menu').css({'height':0});
			}
		  } 
		        if ($(window).width() > 1100) {
				   $('body').getNiceScroll().resize();
				 }
		   return false;
         });
	   
	  $('.sub-menu, .nav li .no-sub, .nav li .blank-sub').mouseleave(function(e){
	   e.preventDefault();
	    if($(window).width() > 1100){
	     $('.nav li, .item-sub').removeClass('active');
	     $('.sub-menu,  .second-sub-menu').css({'height':0});
		 $('.overlay-menu, .header').removeClass('show');
		 $('.title-name li').removeClass('show');
		}
		return false;
      });
	 
	  $('.sub-nav, a.link-home, .container').mouseenter(function(e){
	   e.preventDefault();
	    if($(window).width() > 1100){
	    $('.nav li, .item-sub').removeClass('active');
	    $('.sub-menu,  .second-sub-menu').css({'height':0});
		$('.overlay-menu, .header').removeClass('show');
		$('.title-name li').removeClass('show');
		}
		return false;
     });
	 
	 
	 
	
	  $('.nav li .has-sub').bind('click',function(e){
	   e.preventDefault();
	   if($(window).width() <= 1100){
		 $('.second-sub-menu').css({'height':'auto'});
		 if(!$(this).parent().hasClass('active')){
		  $('.nav li').removeClass('active');
		  $('.sub-menu').css({'height':0});
		  var Top = $(this).parent().offset().top;
		  var OpenPage = $(this).attr('data-sub');
		  var Topx =  $('.sub-menu[data-show= "' + OpenPage + '"]').offset().top;
		  var Hx = $('.sub-menu[data-show= "' + OpenPage + '"]').children().innerHeight();
		  
		  $('.sub-menu[data-show= "' + OpenPage + '"]').css({'height':Hx});
		  
		  var H1 = $('.products[data-show= "' + OpenPage + '"] .all-sub:nth-child(1)').innerHeight();
		  var H2 = $('.products[data-show= "' + OpenPage + '"] .all-sub:nth-child(2)').innerHeight();
		//  var H3 = $('.products[data-show= "' + OpenPage + '"] .all-sub:nth-child(3)').innerHeight();
		   $('.sub-menu.products[data-show= "' + OpenPage + '"]').css({'height':Hx});
		 // $('.products[data-show= "' + OpenPage + '"]').css({'height':H1+H2+H3});
		   $('.products[data-show= "' + OpenPage + '"]').css({'height':H1+H2});
		  
		  var H4 = $('.menu-solutions[data-show= "' + OpenPage + '"] .all-sub:nth-child(1)').innerHeight();
		  var H5 = $('.menu-solutions[data-show= "' + OpenPage + '"] .all-sub:nth-child(2)').innerHeight();
		  $('.sub-menu.menu-solutions[data-show= "' + OpenPage + '"]').css({'height':Hx});
		  $('.menu-solutions[data-show= "' + OpenPage + '"]').css({'height':H4+H5});
		  
		  
		  $(this).parent().addClass('active');
		 }else{
			$('.nav li').removeClass('active');
			$('.sub-menu').css({'height':0});
			$('.item-sub').removeClass('active');
		 }
		
	   }
	   return false;
      });
	  
	  
	
	  
	  
  
  
}


function VideoLoad(idx) {
    $.ajax({url: idx, cache: false, success: function(data) {
            $('.allvideo').append(data);
            $('.allvideo').css({'width': '100%', 'display': 'block'});
			$('.loadicon').fadeOut(300, 'linear', function () {
			    $('.loadicon').remove();
		      });
			
            var ThisVideo = document.getElementById("all-video");
            function playVid() {
                ThisVideo.play();
            }
            function pauseVid() {
                ThisVideo.pause();
            }
            var length = $('#all-video').length;
            $('.close-video').click(function() {
                if (length != 0) {
                    pauseVid();
                }
              
                $('.video-list, .video-skin').fadeOut(500, 'linear', function() {
                    $('.close-video').fadeOut(300, 'linear');
                    $('.overlay-video').fadeOut(500, 'linear', function() {
                        $('.allvideo').css({'width': 0, 'display': 'none'});
                        $('.allvideo .video-list').remove();  
						$('html, body, .container').removeClass('no-scroll');
                    });
                });
		 
		    });
     }
		
		
   });
}







function DetailsLoad(url) { 
  $.ajax({ url: url, cache:false,success: function(data){
	    $('.load-product').append(data);
		     
			 if($(window).width() <= 1100){
				 $('.right-pro').css({'width':'90%','margin':'0 5%'});
			 }else{
			     if($('.left-pro').children().length){
					 $('.right-pro').css({'width':'65%','margin':'0 -2px'});
				 }else{
					 $('.right-pro').css({'width':'90%','margin':'0 5%'});
				 }
			 }
			 
			 
		   $('.load-product').stop().animate({'opacity': 1}, 500, 'linear', function() {
			   $('.all-content-load').addClass('fade-in');
			    if ($(window).width() > 1100 ) {
				 var TopPage = $(document).scrollTop();
				 var Top = $('.top-menu').offset().top;	
				 if(TopPage >= Top - 200){
					 $('.product-pic').each(function() {
					 $(this).children().each(function(i){
					   var box = $(this);
					   setTimeout(function(){$(box).addClass('fadeinup')}, (i+1) * 400);
					  });
                     });
					 
				 $('.application-row').each(function() {
					$(this).children().each(function(i){
					  var box = $(this);
					   setTimeout(function(){$(box).addClass('fadeinup')}, (i+1) * 800);
					 });
                  });
				 }else{
			       $('.product-pic').children().first().addClass('fadeinup');
				   $('.application-pic:first-child').addClass('fadeinup');
				 }
				
				}
				    $('.sub-bottom, .bottom').removeClass('fade-out').addClass('fade-in');
				   $('.loadicon').fadeOut(300, 'linear', function () {
			        $('.loadicon').remove();
					if ($(window).width() > 1100) {
				      $('body').getNiceScroll().resize();
				     }
		          });
			 });
	  
	         $('a.zoom-details').click(function (e) {
				  e.preventDefault();
				  $('.sub-bottom, .bottom').removeClass('fade-in').addClass('fade-out');
				   $('body').append('<div class="loadicon" style="display:block"><span class="circle"></span></div>');
				   $('a.zoom-details').removeClass('active');
				   $(this).addClass('active');
				   var url = $(this).attr('data-href');
				   var name = $(this).attr('data-name');
					$('.product-details').css({'display':'inline-block'}).addClass('showpic');
					
				     $('.product-details').stop().animate({'opacity': 0}, 500, 'linear', function() {
					  $('.load-product').fadeOut(500, 'linear');
					 PicLoad (url, name);
				 });
				return false;
			  });	
	  
	     SlidePicture();
       Option();
	   
	   if($('.zoom-active').text()!=null){
	   	$('.zoom-details[data-id="'+$('.zoom-active').text() + '"]').trigger('click');
	   }
    }
});
}


function PicLoad (url, name) { 
 $.ajax({ url: url, cache:false,success: function(data){
	   $('.product-details').append(data);
	    var gotop =  $('.product-details').offset().top-50;
	    $('.material-slide').BTQSlider({
			 singleItem : true,
			 navigation : true,
			 lazyLoad : true,
			 autoHeight : true,
			 lazyEffect : "fade",
			 slideSpeed: 800,
			 afterAction: function(el){
             this.$BTQItems.removeClass('select');
             this.$BTQItems.eq(this.currentItem).addClass('select');
	          },
			  afterMove: function(el){
				  hiddenZoom();
			  }
          });
	     var Goto = name;
	     $('.material-slide').trigger('BTQ.goTo', Goto);
		 
		 hiddenZoom();
		 $('.zoom-active').text('');
		 
		 $('.sub-bottom, .bottom').removeClass('fade-out').addClass('fade-in');
	     $('.product-details').stop().animate({'opacity': 1}, 600, 'linear');
		       $('.loadicon').fadeOut(300, 'linear', function () {
			       $('.loadicon').remove();
				    if ($(window).width() > 1100) {
				     $('body').getNiceScroll().resize();
				    }
					
				 $('html, body').stop().animate({scrollTop:gotop}, 'slow');
		  });
		  
	                    $('.slide-next, .slide-prev, .slide-page').click(function() {
							 hiddenZoom();
					 	})
	 
    }
});
}

function zoomProduct(){
	
	$('.zoom-full').click(function() {
        $('html, body, .container').addClass('no-scroll');
        $('.all-pics').css({'display': 'block'});
        $('.all-pics').append('<div class="full2" style="display:block"></div>');
        $('.overlay-dark').fadeIn(300, 'linear');
		$('body').append('<div class="loadicon" style="display:block"><span class="circle"></span></div>');
		$('body').append('<div class="close-pics"></div>');
		$('.all-pics').append('<div class="close-pics-small" ></div>'); 
		
		 if ($(window).width() > 1100) {
			 var newActive = $('.slide-item.select').find('.slide-product .pro-full img').attr("data-zoom");
			 //var newActive = activePicLarge.replace("_s", "_l");
			  $('.all-pics').find('.full2').append('<img src ="'+(newActive)+'" alt="pic" />');
		 }else{
			  var activePicLarge = $('.slide-item.select').find('.slide-product .pro-full img').attr("src");
			  $('.all-pics').find('.full2').append('<img src ="'+(activePicLarge)+'" alt="pic" />');
			 
		 }
		 
              $('.all-pics img').load(function() {
                     if ($(window).width() > 1100) {
						if (isTouchDevice && isChrome) {
							$('.all-pics').getNiceScroll().show();
							$('.all-pics').niceScroll({touchbehavior:false,grabcursorenabled: true, horizrailenabled: true, cursordragontouch:true});
							$('.all-pics').animate({scrollTop: "0px"});
						} else {
							$('.all-pics').getNiceScroll().show();
							$('.all-pics').niceScroll({touchbehavior: true, grabcursorenabled: true, horizrailenabled: true, cursordragontouch:true});
							$('.all-pics').animate({scrollTop: "0px"});
						}
					 
					 }else{
					   if(isDesktop){
					        $('.full2').css({'overflow':'hidden'});	 
					        $('.full2').addClass('dragscroll');
					         dragscroll.reset();
					   } else {
						     $('.full2').css({'overflow-x':'auto','overflow-y':'auto','-webkit-overflow-scrolling':'touch'});
					   }
						 
						
					 }
					 
                 if($('.full2 img').length>1){
					$('.full2 img').last().remove()
				 }
              
				$('.loadicon').fadeOut(400, 'linear', function() {
                    $('.loadicon').remove();
					$('.full2 img').addClass('fade-in');
				});
				
            });

        $('.close-pics, .close-pics-small').click(function() {
			$('.loadicon').remove();
			$('.all-pics').scrollTop(0);
			$('.all-pics').getNiceScroll().remove();
            $('.full2, .close-pics, .close-pics-small').fadeOut(300, 'linear');
            $('.overlay-dark').fadeOut(300, 'linear', function() {
                $('.all-pics .full2').remove();
                $('.close-pics, .close-pics-small').remove();
                $('.all-pics').css({'display':'none'});  
				$('html, body, .container').removeClass('no-scroll');
            });
        });
        return false;
      });
	  
	  
}

function NewsLoad(url, OpenTab) {
    $('body').append('<div class="loadicon" style="display:block"><span class="circle"></span></div>');
     $.ajax({url: url, cache: false, success: function(data) {
            $(OpenTab).append(data);
	   
		  $('.news-text p a').attr('target',  '_blank'); 
        
		   $(OpenTab).stop().animate({'opacity': 1}, 600, 'linear', function() {
			    $('.box-content').css({'height':$('.box-content .colum-box.active').innerHeight()});
                $('.loadicon').fadeOut(300, 'linear', function() {
                $('.loadicon').remove();
				$('.box-content').css({'height':$('.box-content .colum-box.active').innerHeight()});
				 if ($(window).width() > 1100) {
				   $('body').getNiceScroll().resize();
				 }
               });

          });
		  Option();

    }
  });
}



function SlidePicture() {
	
	if( $('.slide-bg').length){
	
	  $(".content-present > h2").lettering('words').children("span").lettering().children("span").lettering();
	  var allItem = $('.bg-home').length;
	  if(allItem >1){
			  $('.next-prev').css({'display':'block'}); 
		 }else{
			  $('.next-prev').css({'display':'none'});
		 }
        var Time =  $('.slider-home').attr('data-time')
	
	if (allItem  > 1) {
       $('.slide-bg').BTQSlider({
			autoPlay : Time,
			singleItem : true,
			stopOnHover : true,
			transitionStyle : "fade",
			afterAction: function(el){
			 $('.left-content').removeClass('move');
             this.$BTQItems.removeClass('select');
             this.$BTQItems.eq(this.currentItem).addClass('select');
			  StopTime();
		      addMove();
	          }
          });
	 }
	}
	
	if( $('.cer-content').length){
       $('.cer-content').BTQSlider({
			  itemsCustom : [
			  [0, 1],
			  [500, 1],
			  [600, 2],
			  [700, 2],
			  [1000, 3],
			  ],
             navigation : true,
			 afterInit : function(elem){
             var that = this
             that.BTQControls.prependTo(elem)
            }
			
          });
	 
	}
	
	if( $('.pic-content').length){
		  $('.pic-content').each(function(index, element) {
			if($(window).width() <= 1100){
				TimePlay = false;
			}else{
			
				if(index == 0 || index == 2 || index == 4 || index == 6 || index == 8){
					TimePlay = 3000;
				}else{
					TimePlay = 2000;
				}
			}
			$(element).BTQSlider({
              itemsCustom : [
				[0, 1],
				[500, 1],
				[600, 1],
				[700, 2],
				[1000, 2],
				[1400, 2],
				[1600, 3],
				[1900, 3],
				],
				autoPlay : TimePlay,
            	stopOnHover : true,
				autoHeight : true,
                slideSpeed: 600,
                paginationSpeed: 800,
			    navigation : true,
			    lazyLoad : true,
			    lazyEffect : "fade",
            });
			

        });
		
	 }
	 if ($('.page-download').length) {
			$('.page-download').BTQSlider({
              itemsCustom : [
				[0, 1],
				[500, 1],
				[600, 1],
				[700, 2],
				[1000, 2],
				[1400, 2],
				[1600, 3],
				[1900, 3],
				],
                slideSpeed: 600,
                paginationSpeed: 800,
				autoHeight : true,
			    navigation : true,
			    lazyLoad : true,
			    lazyEffect : "fade",
            });
			
			   var Item = $('.slide-pictures.two').find('.slide-item');
			   if(Item>2){
					$('.slide-pictures.two .slide-item').css({'display':'block', 'float':'left'});
			   }else{
					$('.slide-pictures.two .slide-item').css({'display':'inline-block', 'float':'none'});
					$('.slide-pictures.two  .slide-wrapper').css({'width':'auto'});
			   }
	  }
	 
	 
	if( $('.pro-pic-left').length){
		
		  if($(window).width() <= 1100){
				TimePlay = false;
			}else{
				TimePlay = 3000;
			}
		$('.pro-pic-left').BTQSlider({
			 singleItem : true,
			 stopOnHover : true,
			 navigation : true,
			 autoHeight : true,
			 lazyLoad : true,
			 lazyEffect : "fade",
			 autoPlay : TimePlay
          });
	}
	


     	if( $('.news-link').length){
			$('.news-link').each(function(index, element) {
		     $(element).BTQSlider({
			   itemsCustom : [
				[0, 1],
				[300, 1],
				[400, 2],
				[500, 2],
				[600, 2],
				[700, 2],
				[800, 2],
				[900, 3],
				[1000, 3],
				[1100, 3],
				[1200, 3],
				[1300, 3],
				[1400, 3],
				[1600, 3],
				[1900, 3],
				],
               itemsMobile : false ,
			   navigation : true,
			   pagination : false
			
             });
		  });
	 }
	
		   
	 
	
	 $('.nextslide').click(function(){
           $('.slide-bg').trigger('BTQ.next');
           });
            $('.prevslide').click(function(){
            $('.slide-bg').trigger('BTQ.prev');
          });
	
	 
	
}


function StopTime() {
	if(timex > 0){
		clearTimeout(timex);
		timex = 0;
	}
}

function addMove() {
	 $('.select').find('.left-content').addClass('move');
     $('.content-present').removeClass('move');	
	 $('.content-present  h2').children().children().removeClass('move');
	 $('.slide-item.select').find('.content-present ').addClass('move');
	  
	   $('.move h2').children().children().each(function(i){
		var box = $(this);
		timex = setTimeout(function(){$(box).addClass('move')}, (i+1) * 100);
	   });
	    
} 


function ScrollHoz() {
	var Scroll = $('.tab-menu, #distributor-page .distribution');
	 $(Scroll).addClass('dragscroll');
	  dragscroll.reset();
	if($(window).width() <= 1100){
    $(Scroll).css({'overflow-x':'scroll','overflow-y':'hidden','-ms-touch-action': 'auto','-ms-overflow-style' :'none', 'overflow':' -moz-scrollbars-none','-webkit-overflow-scrolling':'touch'});
	   $(Scroll).animate({scrollLeft: "0px"});
	   if(!isTouchDevice && $(window).width() <= 1100){
	   $(Scroll).mousewheel(function(e, delta) {
			  e.preventDefault();
			 if ($(window).width() <= 1100) {
		       this.scrollLeft -= (delta * 40);
			 }
		 });
	   }
	}
	 
}


function ScrollBody() {
if(!isTouchDevice && $(window).width() > 1100){
   $('body').getNiceScroll();
   $('body').niceScroll({touchbehavior: false,  grabcursorenabled: true, horizrailenabled: false, cursordragontouch:true});
   $('body').animate({scrollTop: "0px"});
   $('body').getNiceScroll().resize();
   $(document).mousemove(function(e){
		 var yMouse = e.pageY;
		 var xMouse = e.pageX;
		 if(xMouse >= $(window).width()-30){
			   $('.nicescroll-rails').css({'width':12, 'background-color':'rgba(0,0,0,0.5)'});
			   $('.nicescroll-rails').find('div').css({'width':12, 'background-color':'rgba(255,255,255,0.5)'});
		 }else{
			   $('.nicescroll-rails').css({'width':6, 'background-color':'rgba(0,0,0,0.3)'});
			   $('.nicescroll-rails').find('div').css({'width':6, 'background-color':'rgba(255,255,255,0.3)'});
		 }
	});
}else{
	$('body').getNiceScroll().remove();
	if($('.full img, .full2 img, .video-list').length){
		$('html, body, .container').addClass('no-scroll');
	}else{
		$('html, body, .container').removeClass('no-scroll');
	}
 }
 
}
function ScrollNiceHide() {
    $('body, .load-all-item').getNiceScroll().remove();
}
function FocusText() {
    var txtholder = 'Họ và Tên (*) HỌ VÀ TÊN (*) HỌ TÊN (*) Họ Tên (*) Họ tên (*) Họ và tên (*)  Địa Chỉ (*) Địa chỉ (*) ĐỊA CHỈ (*) Điện Thoại (*) Điện thoại (*) ĐIỆN THOẠI (*) Email (*) Yêu Cầu (*) YÊU CẦU (*)  EMAIL (*) Công Ty CÔNG TY Công ty  Tìm nhanh... Search... Tìm kiếm... Full Name (*) Full name (*) FULL NAME (*) Company COMPANY TEL (*) Tel (*) PHONE (*) Phone (*)';
    var txtRep = "";
    $('input').focus(function() {
       // txtRep = $(this).val();
		txtRep = $(this).parent().find('.focus-text');
       // if (txtholder.indexOf(txtRep) >= 0) {
           // $(this).val("");
		  $(txtRep).addClass('hide');
        //}
    });
    $('input').focusout(function() {
        if ($(this).val() == ""){
           // $(this).val(txtRep);
		    $(txtRep).removeClass('hide');
		}
    });
    var cur_text = "";
    $('textarea').focus(function() {
       // cur_text = $(this).val();
	   cur_text =  $(this).parent().find('.focus-text')
      //  if (cur_text == 'Ý Kiến (*)' || cur_text == 'NỘI DUNG (*)' || cur_text == 'Ý Kiến của bạn');
       // $(this).val('')
	    $(cur_text).addClass('hide'); 
    }).focusout(function() {
        if ($(this).val() == ""){
           // $(this).val(cur_text)
		    $(cur_text).removeClass('hide');
		}
    });
	
	 $('input[type="reset"]').click(function() {
		 if($('.focus-text').hasClass('hide')){
           $('.focus-text').removeClass('hide');
	    }
    });
	

}




function LinkPage() {
	function  ChangPage(linkLocation){
		$('.overlay-menu').trigger('click');
        var OutCenter = $('.slider-home, .overlay-menu, .home-content, .container, .content-page');
        $(OutCenter).animate({'opacity': 0}, 300, 'linear');
	    window.location = linkLocation;
        
	}
	
	
	
    $('.nav li a.no-sub, .sub-nav li a, a.link-home, a.view-details, a.go-details, .colum-sub .sub-pro a, a.link-direct').click(function(e) {
        e.preventDefault();
        var linkLocation = $(this).attr("href");
		ChangPage(linkLocation);
        return false;
    });
	
	
	 
	
	 $('.box-news').click(function(e) {
        e.preventDefault();
        var linkLocation = $(this).find('a').attr("href");
		ChangPage(linkLocation);
        return false;
    });
	
	  $('.nav li a.blank-sub').click(function(e) {
		   e.preventDefault();
		 $(this).attr('target',  '_blank'); 
         var linkOpen = $(this).attr("href");
	     window.open(linkOpen);
        return false;
     });
	 
	   $('.colum li a.blank-page').click(function(e) {
		   e.preventDefault();
		   $(this).attr('target',  '_blank');
          var linkNew = $(this).attr("href");
	      window.open (linkNew);
        return false;
      });
	
	
	

}


function ContentLoad() {
    ResizeWindows();
    LinkPage();
    FocusText();
	Search();
    SubClick();
	NavClick()
	ScrollBody();
	detectHeight();
	ScrollHoz();
	SlidePicture();
	Option();
	zoomProduct();
	
    $('a.link-home').removeClass('current');
	
	
	
	if(!$('#home-page').length){
		$('.logo').css({'cursor':'pointer'});
		$('.logo').click(function(e) {
             e.preventDefault();
			 $('a.link-home').trigger('click');
		});
	}

	
    //HOME PAGE//
    if ($('#home-page').length) {
		$('a.link-home').addClass('current');
			  $('.close-box').click(function(e) {
                e.preventDefault();
			    $('.left-content').removeClass('move').removeClass('view-box').addClass('hide-box');
				   $('.show-box').css({'display':'block'});
				   $('.close-box').css({'display':'none'});
	        	});
				
			    $('.show-box').click(function(e) {
                  e.preventDefault();
			      $('.left-content').removeClass('hide-box').addClass('view-box').addClass('move');
				  $('.show-box').css({'display':'none'});
				  $('.close-box').css({'display':'block'})
	        	});
		            setTimeout(function(){  
					  $('.box-video .pic img').each(function(index, element) {
						  var RatioPic =  $(this).width() / $(this).height();
						  if(RatioPic < 1 ){
							  $(this).css({'height':'100%', 'margin-top':0, 'width':'auto'});
						  }else{
							  $(this).css({'height':'auto' ,'margin-top':80 - $(this).height()/2, 'width':'100%'});
						  }
				    	});
						
					},  1000);
    }
	
	
	 //COMPANY PAGE//
     if ($('#about-page, #showroom-page,  #consultant-page, #partners-page, #chart-page,  #awards-page,  #documentary-page').length) {
		
		if( $('.box-consulting').length){
		  $('.box-consulting:first').addClass('fadeinup');
		  $('.box-consulting:first').children().addClass('fadeinup');
	     }
	      if( $('.documenttary').length){
			 $('.movie-box:first').addClass('fadeinup');
			 }
			 
		  if ($(window).width() <= 1100) {
		    if($('.nav li.current').length){
			  $('.nav li.current a.has-sub').trigger('click');
	        }
		   }	 
		
      }
	  
	  
	   //SOLUTION PAGE//
     if ($('#solution-page').length) {
		 if($(window).width() > 1100) {
		       $('.wrap-content').each(function() {
					$(this).children().each(function(i){
					  var box = $(this);
					   setTimeout(function(){$(box).addClass('fadeinup')}, (i+1) * 1000);
					  });
                   });
		 }
		 
		   if ($(window).width() <= 1100) {
		    if($('.nav li.current').length){
			  $('.nav li.current a.has-sub').trigger('click');
	        }
		   }
        
      }
	  
	  
	     //PRODUCT PAGE//
     if ($('#product-page').length) {
		 
		     $('.tab-menu li a:not(.download)').click(function (e) {
				  e.preventDefault();
				   $('.sub-bottom, .bottom').removeClass('fade-in').addClass('fade-out');
				   $('body').append('<div class="loadicon" style="display:block"><span class="circle"></span></div>');	
				   $('.tab-menu li').removeClass('current');
				   var url = $(this).attr('href');
				   var Name = $(this).attr('data-name');
				   $(this).parent().addClass('current');
				   if($(window).width() <= 1100) {
					    detectBut();
					 }
				   
				   var tmpurl = $(this).attr('href');
					var tmptitle = $(this).attr('data-title');
					var tmpkeyword = $(this).attr('data-keyword');
					var tmpdescription = $(this).attr('data-description');
					var tmpdataname = $(this).attr('data-name');
					changeUrl(tmpurl,tmptitle,tmpdescription,tmpkeyword,tmpdataname,tmptitle,tmpdescription);
					
					if($('.product-details').hasClass('showpic')){
						 $('.product-details').animate({'opacity': 0}, 500, 'linear', function() {
							 $('.product-details .product-full').remove();
							 $('.load-product .all-content-load').remove();
							 $('.product-details').css({'display':'none'}).removeClass('showpic');
							 $('.load-product').css({'display':'block'});
							 DetailsLoad (url);
						 });
					}else{
				   $('.load-product').stop().animate({'opacity': 0},600, 'linear', function() {
					  $('.load-product .all-content-load').remove();
					  DetailsLoad (url);
				    });
					}
					
				return false;
			  });	
		 
		 
		     $('.close').click(function() {
				  $('.load-product').fadeIn(500, 'linear', function() {
				    var TopY = $('a.zoom-details.active').offset().top - ($('.banner').height()+150);
					$('html, body').stop().animate({scrollTop:TopY}, 'slow');
				});
			       $('.product-details').stop().animate({'opacity': 0},800, 'linear', function() {
				    $('.product-details .product-full').remove();
				    $('.product-details').css({'display':'none'}).removeClass('showpic');
						 $('a.zoom-details').removeClass('active');
						 
			   });
		    
            return false;
          });
		   
	      if($('.tab-menu li.current').length){
			  $('.tab-menu li.current a').trigger('click');
		   }else{
		     $('.tab-menu li:first-child').find('a').trigger('click');
	      }
		  
		   if ($(window).width() <= 1100) {
		    if($('.nav li.current').length){
			  $('.nav li.current a.has-sub').trigger('click');
	        }
		   }
		
      }
	   
	
	 //PROJECTS PAGE//
     if ($('#projects-page').length) {
		
		var PageActive = window.location.hash;
        PageActive = PageActive.slice(1);
		Arrhash = PageActive.split('/');
		 if ($(window).width() > 1100) {
			  if($('.slide-pictures.current').length){
				  var YItem = $('.content-page .slide-pictures[id= "' + $('.slide-pictures.current').attr('id') + '"]').offset().top-40;
					  if($('.zoom.current').length){
						  setTimeout(function() {$(".zoom[data-name='" + $('.zoom.current').attr('data-name') + "']").trigger('click');}, 500);
						  setTimeout(function() {$('html, body').animate({scrollTop: YItem }, 800, 'easeOutExpo');}, 1500);
					  }else{
						  setTimeout(function() {$('html, body').animate({scrollTop: YItem }, 800, 'easeOutExpo');}, 1500);
					  }
				    
				}
		   }else{
				 if($('.zoom.current').length){
					 setTimeout(function() {$(".zoom[data-name='" + $('.zoom.current').attr('data-name') + "']").trigger('click'); }, 500);
				 }
				   
		   }
		   
		 $('.colum li a.go-page').click(function(e) {
		    e.preventDefault();
			
			var tmpurl = $(this).attr('href');
			var tmptitle = $(this).attr('data-title');
			var tmpkeyword = $(this).attr('data-keyword');
			var tmpdescription = $(this).attr('data-description');
			var tmpdataname = $(this).attr('data-name');
			changeUrl(tmpurl,tmptitle,tmpdescription,tmpkeyword,tmpdataname,tmptitle,tmpdescription);
			
		     var Target = $(this).attr('data-name');
			 var YItem =  $('.content-page .slide-pictures[id= "' + Target + '"]').offset().top-40;
           $('html, body').animate({scrollTop: YItem }, 800, 'easeOutExpo');
            return false;
         });
        
      }
	  
	   //GALLERY PAGE//
     if ($('#gallery-page').length) {
		var PageActive = window.location.hash;
        PageActive = PageActive.slice(1);
		
		   if ($(window).width() > 1100) {
			  if($('.slide-pictures.current').length){
				  var YItem = $('.content-page .slide-pictures[id= "' + $('.slide-pictures.current').attr('id') + '"]').offset().top-40;
					 setTimeout(function() {$('html, body').animate({scrollTop: YItem }, 800, 'easeOutExpo');}, 1500);
				}
		   }
		   
		   if($(window).width() <= 1100){
			   $('.pic-content').each(function(index1, element1) {
				$(element1).find(".slide-pagination .slide-page").each(function(index, element) {
				   if(index>4){
					   $(element).css('display','none');
				   }
			   });
			   });
				
			}else{
				$('.pic-content').each(function(index1, element1) {
						 $(element1).find(".slide-pagination .slide-page").each(function(index, element) {
				   //if(index>5){
					   $(element).css('display','inline-block');
				   //}
			   });
				});
			}
		
		
		 $('.colum li a.go-page').click(function(e) {
		    e.preventDefault();
			var tmpurl = $(this).attr('href');
			var tmptitle = $(this).attr('data-title');
			var tmpkeyword = $(this).attr('data-keyword');
			var tmpdescription = $(this).attr('data-description');
			var tmpdataname = $(this).attr('data-name');
			changeUrl(tmpurl,tmptitle,tmpdescription,tmpkeyword,tmpdataname,tmptitle,tmpdescription);
		     var Target = $(this).attr('data-name');
			 var YItem =  $('.content-page .slide-pictures[id= "' + Target + '"]').offset().top-40;
            $('html, body').animate({scrollTop: YItem }, 800, 'easeOutExpo');
            return false;
         });
		
      }
	  
	    //DOWNLOAD PAGE//
     if ($('#download-page').length) {
		
		 $('.item-pic.pdf').click(function(e) {
		    e.preventDefault();
			 $(this).find('a').attr('target',  '_blank'); 
		     var url = $(this).find('a').attr('href');
			 if(url!=undefined){
			 	window.open (url);
			 }
            return false;
         });
		
      }
	  
	  
	      //DISTRIBUTOR PAGE//
     if ($('#distributor-page').length) {
		
		   $('.tab-menu li a').click(function (e) {
				  e.preventDefault();
				   $('.tab-menu li').removeClass('current');
				   $('.distribution').animate({scrollLeft: "0px"});
				   var Name = $(this).attr('data-name');
				   $(this).parent().addClass('current');
				   
				   var tmpurl = $(this).attr('href');
					var tmptitle = $(this).attr('data-title');
					var tmpkeyword = $(this).attr('data-keyword');
					var tmpdescription = $(this).attr('data-description');
					var tmpdataname = $(this).attr('data-name');
					changeUrl(tmpurl,tmptitle,tmpdescription,tmpkeyword,tmpdataname,tmptitle,tmpdescription);
					
				    $('.distribution-info').stop().animate({'opacity': 0 }, 500, 'linear', function() {
						   $('.distribution-info').removeClass('flipInX').css({'display':'none'});
						   $('.distribution-info[id= "' + Name + '"]').css({'display':'block', 'opacity':1});
						   $('.distribution-info[id= "' + Name + '"]').addClass('flipInX');
						   ScrollHoz();
		            });
				   
				return false;
			  });	
		 
	      if($('.tab-menu li.current').length){
			 $('.tab-menu li.current a').trigger('click'); 
		   }else{
		     $('.tab-menu li:first-child').find('a').trigger('click');
	      }
		  
		
        
      }
	  
	  
	    //NEWS PAGE//
     if ($('#news-page').length) {
		
		      $('.link-page').click(function (e) {
				    e.preventDefault();
					$('.active .link-page').removeClass('current');
					$(this).addClass('current');
					var Detail = $(this).find('a').attr("data-details");
			        var url = $(this).find('a').attr('href'); 
			        
					var tmpurl = $(this).find('a').attr('href');
					var tmptitle = $(this).find('a').attr('data-title');
					var tmpkeyword = $(this).find('a').attr('data-keyword');
					var tmpdescription = $(this).find('a').attr('data-description');
					var tmpdataname = $(this).find('a').attr('data-name');
					changeUrl(tmpurl,tmptitle,tmpdescription,tmpkeyword,tmpdataname,tmptitle,tmpdescription);
					
					 var OpenTab = $(this).parent().parent().parent().parent().parent().find('.news-load');
					 $(OpenTab).addClass('select');
					 
					  if(!$(OpenTab).parent().parent().hasClass('active')){
		              var Current = $(OpenTab).parent().parent().attr('id');
		              $(".tab-menu li a[data-target='" + Current + "']").trigger('click');
	                  }
					 
					 
					  $(OpenTab).stop().animate({'opacity': 0}, 600, 'linear', function() {
						   if($(OpenTab).children().length > 0){
							   $(OpenTab).children().remove();
                            } 
							  NewsLoad(url, OpenTab);
                     });
					
					return false;
				});  
		
	
		     $('.tab-menu li a').click(function (e) {
				  e.preventDefault();
				  
				  var allItem = $('.colum-box').length;
                  var widthItem = $('.colum-box').width(); 
                  $('.box-content').width(allItem * widthItem);  
				  $('.tab-menu li').removeClass('current');
				  $('.colum-box').removeClass('active');
				  $(this).parent().addClass('current');
				  var Openpage = $(this).attr('data-target');
				   $('.colum-box[id= "' + Openpage + '"]').addClass('active');
				   
				   if($('.active .link-page.current').length == 0){
					  $('.active .slide-wrapper .slide-item:first-child').find('.link-page:first').trigger('click');
			       }
				        var  Goto = $('.active .slide-item').index($('.active .slide-item .link-page.current').parent());
	                    $('.active .news-link').trigger('BTQ.goTo', Goto);
						
						var XCurrent = $('.box-content').offset().left;
						var XItem = $('.box-content .colum-box[id= "' + Openpage + '"]').offset().left;
						$('.box-content').css({'height':$('.box-content .colum-box.active').innerHeight()});
						$('.box-content').stop().animate({'left': XCurrent - XItem}, 800, 'easeInOutExpo', function() {
						     if ($(window).width() > 1100) {
				                 $('body').getNiceScroll().resize();
				             }else{
								  setTimeout(function(){
									   //ResizeWindows();
									   detectBut();
									  },800);
							 }
						 });
						return false;
			   });
		
			 if($('.slide-wrapper .slide-item .link-page.current').length){
				 $('.slide-wrapper .slide-item .link-page.current').trigger('click');
			 }else{
				 $('.colum-box:first .slide-wrapper .slide-item:first-child').find('.link-page:first').trigger('click');
			 }
		  
		
        
      }
	  
	  //CONTACT PAGE//
     if ($('#contact-page').length) {
		
      }
	  
	  //SEARCH PAGE//
     if ($('#search-page').length) {
		
		   $('.distribution').animate({scrollLeft: "0px"});
		   
		   $('.pagesearch-info').removeClass('flipInX').css({'display':'none'});
		   $('.pagesearch-info').css({'display':'block', 'opacity':1});
		   $('.pagesearch-info').addClass('flipInX');
		   ScrollHoz();
		   
      }
			 

}

    
        


function Option() {
var VideoShow = document.getElementById("video-about");

function ShowVid(VideoShow){
 VideoShow.play();
}
  
function HideVid(VideoShow){
 VideoShow.pause();
}


     $('.scroll-down-desktop').click(function(e){
		  e.preventDefault();
	      $('html, body').animate({scrollTop: $(window).height()/2}, 'slow');
	  });
	
		  
    $('a.player').click(function(e) {
        e.preventDefault();
		 var idx = $(this).attr('data-href');
		  $('body').append('<div class="loadicon" style="display:block"><span class="circle"></span></div>');	
            $('html, body, .container').addClass('no-scroll');
		    $('.overlay-video').fadeIn(500, 'linear', function() {
              VideoLoad(idx);
		  });
        return false;
    });
	
	
	
      $('a.play-video').click(function(e) {
        e.preventDefault();
		$(this).fadeOut(300, 'linear', function() {
		$(this).parent().find('img').addClass('fade-out').addClass('hidden');
		$(this).parent().find('.video-center').addClass('show').addClass('fade-in');	
		$(this).parent().find('.close-video-about').fadeIn(300, 'linear');
		if($(this).parent().find('video').length){
			ShowVid(document.getElementById($(this).parent().find('video').attr('id')));
		}else{
			toggleVideo($(this).parent().find('iframe'));
		}
		if($('#news-page').length){
		$('.box-content').css({'height':$('.box-content .colum-box.active').innerHeight()});
		if ($(window).width() > 1100) {
		   $('body').getNiceScroll().resize();
		 }
		}
		 });
        return false;
    });
	
	 $('.close-video-about').click(function(e) {
		e.preventDefault();
		$(this).fadeOut(300, 'linear', function() {
		$(this).parent().find('a.play-video').fadeIn(300, 'linear');
		$(this).parent().find('img').removeClass('hidden').addClass('fade-in');
		$(this).parent().find('.video-center').addClass('fade-out').removeClass('show'); 
		if($(this).parent().find('video').length){
			HideVid(document.getElementById($(this).parent().find('video').attr('id')));
		}else{
			toggleVideo($(this).parent().find('iframe'), 'hide');
		}
		
		if($('#news-page').length){
		$('.box-content').css({'height':$('.box-content .colum-box.active').innerHeight()});
		if ($(window).width() > 1100) {
		   $('body').getNiceScroll().resize();
		 }
		}
		 });
	   return false;
    });                    
  

    $('.zoom, .show-pic').click(function() {
        $('html, body, .container').addClass('no-scroll');
        $('.all-pics').css({'display': 'block'});
		if($('.pic-name h3, .text-name h3, .text-des h3').length){
			var H = $(this).parent().find('.pic-name h3, .text-name h3, .text-des h3').text();
			var T = $(this).parent().find('.text-des p').text();
			$('.all-pics').append('<div class="text-length"><h3>'+ H +'</h3></div>');
		 }
		
        $('.all-pics').append('<div class="full"  style="display:block"></div>');
        $('.overlay-dark').fadeIn(300, 'linear');
		
		var newActive = $(this).attr("data-src");
	    $('body').append('<div class="loadicon" style="display:block"><span class="circle"></span></div>');
	     $('.all-pics').find('.full').append('<img src ="'+(newActive)+'" alt="pic" />');
		
		
		
			if ($('#projects-page').length) {
				$(this).addClass('current');
				var tmpurl = $(this).attr('href');
				var tmptitle = $(this).attr('data-title');
				var tmpkeyword = $(this).attr('data-keyword');
				var tmpdescription = $(this).attr('data-description');
				var tmpdataname = $(this).attr('data-name');
				changeUrl(tmpurl,tmptitle,tmpdescription,tmpkeyword,tmpdataname,tmptitle,tmpdescription);
			}
		
		
		  $('body').append('<div class="close-pics"></div>');
		  $('.all-pics').append('<div class="close-pics-small"></div>'); 
		  $('.all-pics').append('<div class="show-zoom"></div>');
		  
          $('.all-pics img').load(function() {
			    
                    if ($(window).width() > 1100) {
						if (isTouchDevice && isChrome) {
							$('.all-pics').getNiceScroll().show();
							$('.all-pics').niceScroll({touchbehavior:false,grabcursorenabled: true, horizrailenabled: false, cursordragontouch:true});
							$('.all-pics').animate({scrollTop: "0px"});
						} else {
							$('.all-pics').getNiceScroll().show();
							$('.all-pics').niceScroll({touchbehavior: true, grabcursorenabled: true, horizrailenabled: false, cursordragontouch:true});
							$('.all-pics').animate({scrollTop: "0px"});
						}
						 
					 }else{
						     
						 if(isDesktop){
						   $('.full').css({'overflow':'hidden'});	 
						   $('.full').addClass('dragscroll');
						   dragscroll.reset();
						  } else if (version > 7500 && version < 8500) {
								  detectZoom();	
							       $('.full').css({'overflow-x':'auto','overflow-y':'auto','-webkit-overflow-scrolling':'touch'});
						 }else{
							  $('.full img').addClass('pinch-zoom');
						    	$('.pinch-zoom').each(function () {
                                 new Pic.PinchZoom($(this), {});
                               });
						 }
						 
						 
				 }
				 
                 if($('.full img').length>1){
					$('.full img').last().remove()
				}
              
				$('.loadicon').fadeOut(400, 'linear', function() {
					 detectMargin(); 
                    $('.loadicon').remove();
					$('.full img, .text-length').addClass('fade-in');
					$('.all-pics').addClass('show');
				});
				
            });
			
			
		   $('.show-zoom').bind('click', function() {
				if(!$('.full img').hasClass('fullsize')){
					$('.all-pics .text-length').css({'z-index':'auto'});
				   if ($(window).width() <= 420) {
					  $('.full img').css({'max-width':'300%'}).addClass('fullsize');
				   }else  if ($(window).width() > 420 && $(window).width() <= 620) {
					  $('.full img').css({'max-width':'200%'}).addClass('fullsize');
				   }else{
					  $('.full img').css({'max-width':'inherit'}).addClass('fullsize');
				   }
					 detectMargin();
				}else{
					 $('.all-pics .text-length').css({'z-index':9998});
					 $('.full img').css({'max-width':'100%'}).removeClass('fullsize');
					  detectMargin();
				}
		 });	

        $('.close-pics, .close-pics-small').click(function() {
			
				var httpserver = $('.httpserver').text();
				if ($('#projects-page').length) {
					var tmpurl = $('.zoom.current').attr('href');
					$('.zoom.current').removeClass('current');
					
					tmpurl = tmpurl.replace(httpserver, ""); 
					var tmp = tmpurl.split('/');
					var linkurl = httpserver + tmp[0] + '/' + tmp[1] + '.html';
					var tmptitle = $('.go-page[href="'+linkurl+'"]').attr('data-title');
					var tmpkeyword = $('.go-page[href="'+linkurl+'"]').attr('data-keyword');
					var tmpdescription = $('.go-page[href="'+linkurl+'"]').attr('data-description');
					var tmpdataname = $('.go-page[href="'+linkurl+'"]').attr('data-name');
					changeUrl(linkurl,tmptitle,tmpdescription,tmpkeyword,tmpdataname,tmptitle,tmpdescription);
				}
			
			
			$('.all-pics').scrollTop(0);
			$('.loadicon').remove();
			$('.all-pics').getNiceScroll().remove();
            $('.full, .close-pics, .close-pics-small').fadeOut(300, 'linear');
            $('.overlay-dark').fadeOut(300, 'linear', function() {
                $('.all-pics .full, .all-pics .show-zoom, .all-pics .text-length').remove();
                $('.close-pics, .close-pics-small').remove();
                $('.all-pics').css({'display':'none'}).removeClass('show');  
				$('html, body, .container').removeClass('no-scroll');
            });
        });
        return false;
		
		
		
    });
	


 $(document).bind('scroll', function() {
        var windscroll = $(document).scrollTop();
		
        if ($(window).width() <= 1100) {
		    if (windscroll > 50) {
                $('.scroll-down').fadeOut(500, 'linear');
            } else {
                $('.scroll-down').fadeIn(500, 'linear');
            }  
		}
		
		
		if(windscroll > $(window).height()/2) {
		  $('.go-top').css({'display':'block', 'opacity':1});
	   }else {
		  $('.go-top').css({'display':'none', 'opacity':0});
	    }
	   
	   if(windscroll >= 50){
		  if ($(window).width() > 1100) {
			$('.scroll-down-desktop').removeClass('fadeon').addClass('fadeoff'); 
		   }
	  }else if(windscroll < 50){
		  if ($(window).width() > 1100) {
			  $('.scroll-down-desktop').removeClass('fadeoff').addClass('fadeon');
		  }
	   }
	   
	         if(windscroll >= 70){
	             if ($(window).width() > 1100) {
				     $('.wrap-page').children().each(function(i){
					  var box = $(this);
					   setTimeout(function(){$(box).removeClass('fade-out').addClass('fadeinup')}, (i+1) * 200);
					 });
					 
					  $('.banner').addClass('dark');
				  }
				  
			    }else{
				   if ($(window).width() > 1100 ) {
					    $('.wrap-page').children().removeClass('fadeinup').addClass('fade-out');
						$('.banner').removeClass('dark');
				    }
			 }
			 
			 if( $('.box-consulting').length){
			 if ($(window).width() > 1100 ) {
			   $('.box-consulting').each(function() {
                var top = $(this).offset().top - ($('.banner').height()+200);
                var bottom = top + $(this).outerHeight();

                if (windscroll >= top && windscroll <= bottom) {
                    $(this).addClass('fadeinup');
					$(this).children().each(function(i){
					  var box = $(this);
					   setTimeout(function(){$(box).addClass('fadeinup')}, (i+1) * 400);
					 });
                    }
                   });
				 }
			 }
			 
			  if( $('.documenttary').length){
			 if ($(window).width() > 1100 ) {
			   $('.movie-box').each(function() {
                var top = $(this).offset().top - ($('.banner').height()+200);
                var bottom = top + $(this).outerHeight();
                if (windscroll >= top && windscroll <= bottom) {
					$(this).each(function(i){
					  var box = $(this);
					   setTimeout(function(){$(box).addClass('fadeinup')}, (i+1) * 400);
					 });
                    }
                   });
				 }
			 }
			 
		 if( $('.product-pic').length){
			 if ($(window).width() > 1100 ) {
			   $('.product-pic').each(function() {
                var top = $(this).offset().top - ($('.banner').height()+200);
                var bottom = top + $(this).outerHeight();
                if (windscroll >= top && windscroll <= bottom) {
					$(this).children().each(function(i){
					  var box = $(this);
					   setTimeout(function(){$(box).addClass('fadeinup')}, (i+1) * 400);
					 });
                    }
                   });
				 }
			 }
			 
		   if( $('.application-row').length){
			 if ($(window).width() > 1100 ) {
			   $('.application-row').each(function() {
                 if (windscroll >= $('.banner').height()-250) {
					$(this).children().each(function(i){
					  var box = $(this);
					   setTimeout(function(){$(box).addClass('fadeinup')}, (i+1) * 800);
					 });
					}
                  });
				 }
			 }
			 
			
					
    });
	
	
	
   $('.go-top').click(function() {
        $('html, body').stop().animate({scrollTop: 0}, 'slow');
    });

 
}
		  

function detectMargin() {
var ImgW = $('.full').children().width();
var ImgH = $('.full').children().height();
var Yheight = $(window).height();
var Xwidth = $(window).width();

	if (Xwidth > ImgW) {
		  $('.full').children().css({'margin-left': Xwidth / 2 - ImgW / 2});
	  } else {
		  $('.full').children().css({'margin-left': 0});
	  }
	  if (Yheight > ImgH) {
		  $('.full').children().css({'margin-top': Yheight / 2 - ImgH / 2});
	  } else {
		  $('.full').children().css({'margin-top':  0});
	  }
}
function detectZoom() {
  var ImgW = $('.full img').width();
  var ImgH = $('.full img').height();
  var Yheight = $(window).height();
  var Xwidth = $(window).width();
  if(ImgW > Xwidth){
	$('.show-zoom').addClass('show');
    $('.full img').addClass('fullsize');
  }else{
    $('.full img').removeClass('fullsize');
  }
}
function detectHeight() {
 if ($(window).width() <= 1100) {	
  var DH = $(document).innerHeight();
  if(DH > $(window).height() + 100){
	$('.scroll-down').css({'display':'block', 'opacity':1});
  }else{
	$('.scroll-down').css({'display':'none', 'opacity':0});
  }
 }
}


function detectBut() {

if($(window).width() <= 1100){
	if($('.tab-menu').length){
	 // $('.tab-menu').scrollLeft(0);  
	  var Left  = $('.tab-menu ul').offset().left;
	  var XLeft = $('.tab-menu li.current').offset().left;
	  var Percent = $(window).width()/100 * 10;
	  var Center =  ($(window).width() - Percent)/2 - $('.tab-menu li.current').width()/2;
	  $('.tab-menu').stop().animate({scrollLeft:  (XLeft-Center) - Left},  'slow', function() {
		    if($('#news-page').length){ 
	         $('.box-content').css({'height':$('.box-content .colum-box.active').innerHeight()});
           }
	});
   }
  
}
	
   
}



$(document).ready(function() {


$('.container').click(function() {
	  $('.nav-click').removeClass('active');
	  $('.nav li, .item-sub').removeClass('active');
	  $('.sub-menu,  .second-sub-menu').css({'height':0});
	  $('.overlay-menu, .header, .top, .logo').removeClass('show');
	  $('.container').removeClass('wrap');  
	  $('html, body, .container').removeClass('no-scroll');
	  $('html, body, .container').removeClass('no-scroll-nav');
	  $('.title-name li').removeClass('show');
	   if (show == 1) {
		  $('.form-row-search').css({'width': 0});
		  $('.search-form').css({'width': 0, 'opacity':0});
		  $('a.search').removeClass('active');
		  show = 0;
	   }
		
 });
 
 $('.overlay-menu').click(function() {
        if ($(window).width() <= 1100) {
			Scroll = 0;
			$('.container').removeClass('wrap');
            $('.nav-click').removeClass('active');
            $('.overlay-menu, .top, .header, .logo').removeClass('show');  
			$('html, body, .container').removeClass('no-scroll-nav');
		}
		
 });


  

    
     

   

 
});



window.onorientationchange = ResizeWindows;

$(window).resize(function() {
    ResizeWindows();
	ScrollBody();
	 
});




$(window).on('resize', function() {
   ResizeWindows();
  
//-----------------------------			
//  DESKTOP 	
    if ($(window).width() > 1100) {
	 $('.container').trigger('click'); 
	if($('.full img').length){
	   if (isTouchDevice && isChrome) {
			$('.all-pics').getNiceScroll().show();
			$('.all-pics').niceScroll({touchbehavior:false,grabcursorenabled: true, horizrailenabled: false, cursordragontouch:true});
			$('.all-pics').animate({scrollTop: "0px"});
		} else {
			$('.all-pics').getNiceScroll().show();
			$('.all-pics').niceScroll({touchbehavior: true, grabcursorenabled: true, horizrailenabled: false, cursordragontouch:true});
			$('.all-pics').animate({scrollTop: "0px"});
		 }
		  detectMargin();
	}
	
	if($('.full2 img').length){
	   if (isTouchDevice && isChrome) {
			$('.all-pics').getNiceScroll().show();
			$('.all-pics').niceScroll({touchbehavior:false,grabcursorenabled: true, horizrailenabled: true, cursordragontouch:true});
			$('.all-pics').animate({scrollTop: "0px"});
		} else {
			$('.all-pics').getNiceScroll().show();
			$('.all-pics').niceScroll({touchbehavior: true, grabcursorenabled: true, horizrailenabled: true, cursordragontouch:true});
			$('.all-pics').animate({scrollTop: "0px"});
		 }
		 
	}
	
	
	 if ($('#solution-page').length) {
		 $('.content-solution, .solution-pic').addClass('fadeinup');
      }
	  
	  
	   $('.navigation, .sub-nav').css({'width':$(window).width()-452});
	   $('.nav').css({'width':$(window).width()-503});
	     
//  DESKTOP 

//-----------------------------		
 
//  MOBILE 		
    } else {
		 $('.wrap-page').children().removeClass('fadeinup').removeClass('slide-fade-out'); 
		 $('div .fadeinup').removeClass('fadeinup'); 
		 $('div .slide-fade-out').removeClass('slide-fade-out');
		 detectHeight();
		 ScrollHoz();
		 $('.navigation,.nav, .sub-nav').css({'width':'100%'});
	
	
		if($('.full img, .full2 img').length){
		     $('.all-pics').getNiceScroll().remove();
		        detectMargin();
				if(isDesktop){
					 $('.full, .full2').css({'overflow':'hidden'});	
					 if(!$('.full, .full2').hasClass('.dragscroll')){ 
					    $('.full, .full2').addClass('dragscroll');
					    dragscroll.reset();
					 }
				 }
			
		    }
	
      }
	
//  MOBILE 	 
//-----------------------------	


  hiddenZoom();
  if($('#news-page').length){ 
      $('.tab-menu li.current a').trigger('click');
  }
   
}, 250);





$(window).bind("popstate", function(e) {
	 e.preventDefault();
	 
	 var httpserver = $('.httpserver').text();
	  
	  if (e.originalEvent.state !== null) {
        var tmp_url = e.originalEvent.state.path;
        var tmp_dataName = e.originalEvent.state.dataName;
        var tmptitle = e.originalEvent.state.title;
        var tmpurl = document.URL;

        changeUrl(tmp_url, tmptitle, '', '', tmp_dataName, '', '');
		
		if ($('#distributor-page').length) {
                $(".tab-menu li a").each(function(index, element) {
					if ($(element).attr('href') == tmp_url) {
						$(element).trigger('click');
					}
                });
        }
		
		if ($('#news-page').length) {
                $(".link-page a").each(function(index, element) {
					if ($(element).attr('href') == tmp_url) {
						$(element).trigger('click');
					}
                });
        }
		
		if ($('#product-page').length) {
                $(".tab-menu li a").each(function(index, element) {
					if ($(element).attr('href') == tmp_url) {
						$(element).trigger('click');
					}
                });
        }
		
		if ($('#projects-page').length) {
			if ($('.close-pics').length) {
                $('.close-pics').trigger('click');
            } else {
				$(".zoom").each(function(index, element) {
					if ($(element).attr('href') == tmp_url) {
						$(element).trigger('click');
					}
                });
				
                $(".go-page").each(function(index, element) {
					if ($(element).attr('href') == tmp_url) {
						$(element).trigger('click');
					}
                });
			}
        }
		
		

	  }else{
		  var tmpurl = document.URL;
		  
		  if ($('#distributor-page').length) {
                $(".tab-menu li a").each(function(index, element) {
					if ($(element).attr('href') == tmpurl) {
						$(element).trigger('click');
					}
                });
        }
		
		if ($('#news-page').length) {
                $(".link-page a").each(function(index, element) {
					if ($(element).attr('href') == tmpurl) {
						$(element).trigger('click');
					}
                });
        }
		
		if ($('#product-page').length) {
                $(".tab-menu li a").each(function(index, element) {
					if ($(element).attr('href') == tmpurl) {
						$(element).trigger('click');
					}
                });
        }
		
		  if ($('#projects-page').length) {
			if ($('.close-pics').length) {
                $('.close-pics').trigger('click');
            } else {
				$(".zoom").each(function(index, element) {
					if ($(element).attr('href') == tmpurl) {
						$(element).trigger('click');
					}
                });
				
                $(".go-page").each(function(index, element) {
					if ($(element).attr('href') == tmpurl) {
						$(element).trigger('click');
					}
                });
			}
        }
		
	  }
	  
	  
	  
	  
});